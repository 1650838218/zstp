package com.example;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping(value = "com/sinosoft")
public class Test {
	
	@RequestMapping(value = "/tt", method = RequestMethod.GET)
	public String tt() {
		System.out.println("44444444444444444");
		Logger log = Logger.getLogger(Test.class);
		log.debug("log4j debug");
		log.info("log4j info");
		log.warn("log4j warn");
		log.error("log4j error");
		return "index";
	}
}
